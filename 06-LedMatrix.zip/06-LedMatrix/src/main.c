
#include "LIB/STD_TYPES.h"

#include "MCAL/RCC/RCC_int.h"

#include "LEDMTX/LEDMTX_int.h"

int main(void)
{

	MRCC_vInit();
	MRCC_vEnableClock(AHB,GPIOA);
	MRCC_vEnableClock(AHB,GPIOB);

	LEDMTX_vInit();


	u8 smiley[] = {16, 32, 76, 64, 64, 76, 32, 16};

	while(1)
	{
		LEDMTX_vDisplayFrame(smiley, 1000);
	}
}
