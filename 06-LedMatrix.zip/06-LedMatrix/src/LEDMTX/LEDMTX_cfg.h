/*
 * LEDMTX_cfg.h
 *
 *  Created on: Sep 6, 2022
 *      Author: mazen
 */

#ifndef LEDMTX_LEDMTX_CFG_H_
#define LEDMTX_LEDMTX_CFG_H_

#define NO_COLS   8
#define NO_ROWS   8

#define SCAN_TIME			2500 //[# Timer Ticks] just an example

extern MGPIO_Config_t rows[NO_ROWS] ;
extern MGPIO_Config_t cols[NO_COLS] ;

#endif /* LEDMTX_LEDMTX_CFG_H_ */
