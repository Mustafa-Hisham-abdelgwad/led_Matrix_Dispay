/*
 * LEDMTX_prg.c
 *
 *  Created on: Sep 6, 2022
 *      Author: mazen
 */



#include "../LIB/STD_TYPES.h"


#include "../MCAL/GPIO/GPIO_int.h"
#include "../MCAL/STK/STK_int.h"


#include "LEDMTX_prv.h"
#include "LEDMTX_cfg.h"
#include "LEDMTX_int.h"


void LEDMTX_vInit(void)
{
	for(int i=0; i<NO_COLS; i++)
	{
		MGPIO_vInit(&cols[i]);
	}
	for(int i=0; i<NO_ROWS; i++)
	{
		MGPIO_vInit(&rows[i]);
	}

	MSTK_vInit();
}

static void LEDMTX_vDisableAllColumns(void)
{
	for(int i=0; i<NO_COLS; i++)
	{
		MGPIO_vSetPinVal(cols[i].Port, cols[i].Pin, GPIO_LOW);
	}
}

static void LEDMTX_vSetRowValues(u8 A_u8row_values)
{
	for(int i=0; i<NO_ROWS; i++)
	{
		MGPIO_vSetPinVal(rows[i].Port, rows[i].Pin, GET_BIT(A_u8row_values, i) );
	}
}


static void LEDMTX_vSetCurrentColumn( u8 A_u8ColNo)
{
	MGPIO_vSetPinVal(cols[A_u8ColNo].Port,cols[A_u8ColNo].Pin, GPIO_HIGH );
}


void LEDMTX_vDisplayFrame(u8 A_u8frame[], u32 A_u32frame_delay)
{
//	u32 Lu32Count = 0 ;
	for(int j=0; j<A_u32frame_delay; j++)
	{
		for(int i=0; i<NO_COLS; i++)
		{
			/* 1- disable all columns */
			LEDMTX_vDisableAllColumns();
			/* 2- set row values      */
			LEDMTX_vSetRowValues(A_u8frame[i]) ;
			/* 3- set current column  */
			LEDMTX_vSetCurrentColumn(i);
			/* 4- delay for suitable FPS*/
			MSTK_vSetBusyWait(SCAN_TIME); /* 2.5 ms */
		}
	}
}


void LEDMTX_vDisplayMatrix(u8 matrix[][NO_COLS], u32 matrix_delay )
{

}



