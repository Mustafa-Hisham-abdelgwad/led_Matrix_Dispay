/*
 * LEDMTX_int.h
 *
 *  Created on: Sep 6, 2022
 *      Author: mazen
 */

#ifndef LEDMTX_LEDMTX_INT_H_
#define LEDMTX_LEDMTX_INT_H_


void LEDMTX_vInit(void);

void LEDMTX_vDisplayFrame(u8 frame[], u32 frame_delay);

void LEDMTX_vDisplayMatrix(u8 matrix[][NO_COLS], u32 matrix_delay );


#endif /* LEDMTX_LEDMTX_INT_H_ */
