/*
 * EXYI_cfg.h
 *
 *  Created on: Aug 30, 2022
 *      Author: mazen
 */

#ifndef MCAL_EXTI_EXTI_CFG_H_
#define MCAL_EXTI_EXTI_CFG_H_

#define EXTI_LINE_0_EN				ENABLE
#define EXTI_LINE_0_TRIGGER			EXTI_RISING

#define EXTI_LINE_1_EN				ENABLE
#define EXTI_LINE_1_TRIGGER			EXTI_RISING





#endif /* MCAL_EXTI_EXTI_CFG_H_ */
