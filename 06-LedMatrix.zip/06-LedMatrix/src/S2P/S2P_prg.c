/*
 * S2P_prg.c
 *
 *  Created on: Sep 6, 2022
 *      Author: mazen
 */




#include "../LIB/STD_TYPES.h"

#include "S2P_int.h"
#include "S2P_prv.h"
#include "S2P_cfg.h"


void S2P_vInit(void)
{
	MGPIO_Config_t S2p_shift_pin = {

	};

	MGPIO_Config_t S2p_latch_pin = {

		};

	MGPIO_Config_t S2p_data_pin = {

		};

	MGPIO_vInit(&S2p_shift_pin);
	MGPIO_vInit(&S2p_latch_pin);
	MGPIO_vInit(&S2p_data_pin);


}

void S2PvSendData(u32 A_u32Data)
{
	/* 1- put data on data pin */
	/* 2- Shift data using shift pin
	 * 	2a- send high
	 * 	2b- delay
	 * 	2c- send low
	 *
	 * */

	/* 3- send a latch signal for the output
	 * 	3a- send high
	 * 	3b- delay
	 * 	3c- send low
	 *
	 *  */



}
