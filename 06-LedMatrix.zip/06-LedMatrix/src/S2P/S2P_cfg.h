/*
 * S2P_cfg.h
 *
 *  Created on: Sep 6, 2022
 *      Author: mazen
 */

#ifndef S2P_S2P_CFG_H_
#define S2P_S2P_CFG_H_





#endif /* S2P_S2P_CFG_H_ */
