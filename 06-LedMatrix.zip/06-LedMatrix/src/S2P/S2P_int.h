/*
 * S2P_int.h
 *
 *  Created on: Sep 6, 2022
 *      Author: mazen
 */

#ifndef S2P_S2P_INT_H_
#define S2P_S2P_INT_H_


void S2P_vInit(void);
void S2PvSendData(u32 A_u32Data);


#endif /* S2P_S2P_INT_H_ */
